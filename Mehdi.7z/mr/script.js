{
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "request.php", true);
    ajax.send();
    
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            console.log(data);
    
            localStorage.setItem('testtest', JSON.stringify(data));
            var data = JSON.parse(localStorage.getItem("testtest"));
        
            

            for(var b = 0; b < 50; b++) {
                var {nom, prenom, age} = data[b];
                felklkl(nom, prenom, age);
            }
        }
    };
}


function felklkl(nom, prenom, age) {
    const nameList = document.getElementById('Mytable1');

    nameList.innerHTML += "<tr><td>" + nom  + "</td> <td>" + prenom + " </td><td>" + age + "</td> </tr>";

}

felklkl('test', 'test', 'test');