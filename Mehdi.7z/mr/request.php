<?php
$conn = mysqli_connect("172.16.96.200", "portail_dsit", "Dsit@2018", "glpi_db");
$result = mysqli_query($conn, "SELECT * FROM theo_table_test");

$data = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data, $row);
}

echo json_encode($data);
exit();

?>